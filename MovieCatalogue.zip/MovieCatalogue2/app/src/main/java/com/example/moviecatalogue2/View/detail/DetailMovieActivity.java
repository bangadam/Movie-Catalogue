package com.example.moviecatalogue2.View.detail;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.moviecatalogue2.Model.MovieResults;
import com.example.moviecatalogue2.Model.TvResults;
import com.example.moviecatalogue2.R;
import com.example.moviecatalogue2.Utils.UtilsConstant;

import butterknife.BindView;
import butterknife.ButterKnife;

public class DetailMovieActivity extends AppCompatActivity {

    @BindView(R.id.title_movie) TextView tvTitle;
    @BindView(R.id.tgl_detail_movie) TextView tvDate;
    @BindView(R.id.description_movie) TextView tvDescription;
    @BindView(R.id.img_detail_movie) ImageView imgPoster;
    @BindView(R.id.bg_img_detail_movie) ImageView imgBg;
    @BindView(R.id.score_detail_movie) RatingBar rbScoreMovie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);
        ButterKnife.bind(this);

        if (getIntent().getStringExtra("fragment").equals("movie")) {
            MovieResults movieModel = getIntent().getParcelableExtra("key");
            tvTitle.setText(movieModel.getTitle());
            tvDate.setText(movieModel.getReleaseDate());
            tvDescription.setText(movieModel.getDescription());
            rbScoreMovie.setRating(movieModel.getRating()/2);

            Glide.with(this).load(UtilsConstant.BASE_BACKDROP_URL+movieModel.getBackgroundImg()).into(imgBg);
            Glide.with(this).load(UtilsConstant.BASE_POSTER_URL+movieModel.getPosterImg()).into(imgPoster);

        } else if (getIntent().getStringExtra("fragment").equals("tv")) {
            TvResults tvResults = getIntent().getParcelableExtra("key");
            tvTitle.setText(tvResults.getTitle());
            tvDate.setText(tvResults.getFirstAirDate());
            tvDescription.setText(tvResults.getDescription());
            rbScoreMovie.setRating(tvResults.getRating()/2);

            Glide.with(this).load(UtilsConstant.BASE_BACKDROP_URL+tvResults.getBgImg()).into(imgBg);
            Glide.with(this).load(UtilsConstant.BASE_POSTER_URL+tvResults.getPosterImg()).into(imgPoster);
        }

    }
}

package com.example.moviecatalogue2.Utils;

public class UtilsConstant {
    public static final String BASE_URL = "http://api.themoviedb.org/3/";
    public final static String API_KEY = "157dd28b253b7303a47817cbdede59ae";
    public final static String BASE_POSTER_URL = "http://image.tmdb.org/t/p/w185";
    public final static String BASE_BACKDROP_URL = "http://image.tmdb.org/t/p/w780";
}
